using Terraria.ModLoader;

namespace VexHotkeys
{
    class VexHotkeys : Mod
    {
        public static ModHotKey PiggyBankHotKey;
        public static ModHotKey SummonStaffHotKey;
        public static ModHotKey SafeHotKey;
        public static ModHotKey BugNetKey;
        public static ModHotKey QuestFishKey;
        public static ModHotKey TomeKey;

        public static ModHotKey QuickUseKey1;
        public static ModHotKey QuickUseKey2;
        public static ModHotKey QuickUseKey3;
        public static ModHotKey QuickUseKey4;
        public static ModHotKey QuickUseKey5;
        public static ModHotKey QuickUseKey6;
        public static ModHotKey QuickUseKey7;
        public static ModHotKey QuickUseKey8;
        public static ModHotKey QuickUseKey9;
        public static ModHotKey QuickUseKey10;

        public static ModHotKey QuickUseKey11;
        public static ModHotKey QuickUseKey12;
        public static ModHotKey QuickUseKey13;
        public static ModHotKey QuickUseKey14;
        public static ModHotKey QuickUseKey15;
        public static ModHotKey QuickUseKey16;
        public static ModHotKey QuickUseKey17;
        public static ModHotKey QuickUseKey18;
        public static ModHotKey QuickUseKey19;

        public VexHotkeys()
        {
            Properties = new ModProperties()
            {
                Autoload = true,
                AutoloadGores = true,
                AutoloadSounds = true
            };
        }


        public override void Load()
        {
            // Registers all the hotkeys
            PiggyBankHotKey = RegisterHotKey("Piggy Bank", "NumPad1");
            SummonStaffHotKey = RegisterHotKey("Summon Staff", "Add");
            SafeHotKey = RegisterHotKey("Select Safe", "NumPad2");
            BugNetKey = RegisterHotKey("Bug Net", "T");
            QuestFishKey = RegisterHotKey("Quest Fish", "NumPad5");
            TomeKey = RegisterHotKey("Tome of Sight", "NumPad3");

            QuickUseKey1 = RegisterHotKey("Alt-Use 1", "B");
            QuickUseKey2 = RegisterHotKey("Alt-Use 2", "N");
            QuickUseKey3 = RegisterHotKey("Alt-Use 3", "M");
            QuickUseKey4 = RegisterHotKey("Alt-Use 4", "J");
            QuickUseKey5 = RegisterHotKey("Alt-Use 5", "K");
            QuickUseKey6 = RegisterHotKey("Alt-Use 6", "L");
            QuickUseKey7 = RegisterHotKey("Alt-Use 7", "I");
            QuickUseKey8 = RegisterHotKey("Alt-Use 8", "O");
            QuickUseKey9 = RegisterHotKey("Alt-Use 9", "P");
            QuickUseKey10 = RegisterHotKey("Alt-Use 10", "B");


            QuickUseKey11 = RegisterHotKey("Alt-Use 11", "B");
            QuickUseKey12 = RegisterHotKey("Alt-Use 12", "N");
            QuickUseKey13 = RegisterHotKey("Alt-Use 13", "M");
            QuickUseKey14 = RegisterHotKey("Alt-Use 14", "J");
            QuickUseKey15 = RegisterHotKey("Alt-Use 15", "K");
            QuickUseKey16 = RegisterHotKey("Alt-Use 16", "L");
            QuickUseKey17 = RegisterHotKey("Alt-Use 17", "I");
            QuickUseKey18 = RegisterHotKey("Alt-Use 18", "O");
            QuickUseKey19 = RegisterHotKey("Alt-Use 19", "P");

            base.Load();
        }

        public override void Unload()
        {
            // Unload all the hotkeys
            PiggyBankHotKey = null;
            SummonStaffHotKey = null;
            SafeHotKey = null;
            BugNetKey = null;
            QuestFishKey = null;
            TomeKey = null;

            QuickUseKey1 = null;
            QuickUseKey2 = null;
            QuickUseKey3 = null;
            QuickUseKey4 = null;
            QuickUseKey5 = null;
            QuickUseKey6 = null;
            QuickUseKey7 = null;
            QuickUseKey8 = null;
            QuickUseKey9 = null;
            QuickUseKey10 = null;

            QuickUseKey11 = null;
            QuickUseKey12 = null;
            QuickUseKey13 = null;
            QuickUseKey14 = null;
            QuickUseKey15 = null;
            QuickUseKey16 = null;
            QuickUseKey17 = null;
            QuickUseKey18 = null;
            QuickUseKey19 = null;

            base.Unload();
        }
    }
}
