using Microsoft.Xna.Framework;
using Terraria;
using Terraria.GameInput;
using Terraria.ID;
using Terraria.ModLoader;

// Inspired by jopojelly's Helpful Hotkeys mod
// https://forums.terraria.org/index.php?threads/helpful-hotkeys.39382/

namespace VexHotkeys
{
    public class VexPlayer : ModPlayer
	{
        // Index of item used before alt-using
        private int lastUseIndex = 0;

        // Index of item to be alt-used
        private int altUseIndex = 0;
        
        // Time left for quick-use
        private int quickUseTime = 0;

        // Whether or not the player is currently quick-using
        private bool quickUsing = false;


        // Whether or not we need to revert the alt-using state this frame
        private bool revertAltUsing = false;

        // Whether or not alt-use is currently being held down
        private bool altUseHeldDown = false;

        // Whether or not we need to revert to last item used this frame
        private bool revertToHotbar = false;

        // Whether or not we need to force the left mouse down
        private bool forceMouseLeft = false;


        // The ModHotKey currently being pressed
        private ModHotKey altUseHotkey = null;

        // Switches to the specified item at the specified index, and uses it
        private void QuickUseItem(Item item, int index)
        {
            // Remember item currently held
            lastUseIndex = player.selectedItem;

            // Remember the use time of the new item
            quickUseTime = item.useTime;

            // Remember that we're currently quick-using
            quickUsing = true;

            // Select the specified item
            player.selectedItem = index;

            // Use the item
            player.controlUseItem = true;
            player.ItemCheck(Main.myPlayer);
            return;
        }

        // Simulates right clicking the Money Trough projectile
        // Called directly after spawning one with a Money Trough
        private void rightClickPiggy(Player player)
        {
            // First, make sure you actually spawned a piggy bank
            for(int i = 0; i < Main.projectile.Length; i++)
            {
                Projectile proj = Main.projectile[i];
                if (proj.type == ProjectileID.FlyingPiggyBank && proj.active && proj.owner == player.whoAmI)
                {
                    // Reset player's use time (negates Money Trough swing)
                    player.itemTime = 0;
                    player.itemAnimation = 0;

                    // Revert to last item used
                    player.selectedItem = lastUseIndex;
                    player.controlUseItem = false;
                    quickUseTime = 0;
                    quickUsing = false;

                    // Set the piggy bank to player's position (prevents rare bug)
                    proj.position = player.Center;

                    // Set ownership of the piggy bank, and set player's chest screen to piggy bank mode
                    player.flyingPigChest = i;
                    player.chest = -2;

                    // Set chest position
                    player.chestX = (int)(player.Center.X / 16.0);
                    player.chestY = (int)(player.Center.Y / 16.0);

                    // Negate other windows
                    player.talkNPC = -1;
                    Main.npcShop = 0;
                    Main.playerInventory = true;
                    Main.PlaySound(SoundID.Item59, -1, -1);
                    Recipe.FindRecipes();

                    return;
                }
            }
        }


        public override void ProcessTriggers(TriggersSet triggersSet)
        {
            // Use Money Trough
            if(VexHotkeys.PiggyBankHotKey.JustPressed)
            {
                if (player.itemAnimation == 0 && !quickUsing)
                {
                    for (int i = 0; i < player.inventory.Length; i++)
                    {
                        Item item = player.inventory[i];

                        if (item.stack > 0 && item.Name == "Money Trough")
                        {
                            QuickUseItem(item, i);

                            // Automatically use the piggy bank projectile
                            rightClickPiggy(player);
                            break;
                        }
                    }
                }
            }

            // Use first available summon staff
            if(VexHotkeys.SummonStaffHotKey.JustPressed)
            {
                if (player.itemAnimation == 0 && !quickUsing)
                {
                    for (int i = 0; i < player.inventory.Length; i++)
                    {
                        Item item = player.inventory[i];

                        if (item.stack > 0 && item.summon && !item.DD2Summon)
                        {
                            QuickUseItem(item, i);
                            break;
                        }
                    }
                }
            }

            // Switch to safe
            if (VexHotkeys.SafeHotKey.JustPressed)
            {
                if (player.itemAnimation == 0 && !quickUsing)
                {
                    for (int i = 0; i < player.inventory.Length; i++)
                    {
                        Item item = player.inventory[i];

                        if (item.stack > 0 && item.Name == "Safe")
                        {
                            player.selectedItem = i;
                            break;
                        }
                    }
                }
            }

            // Switch to bug net and use it immediately
            if (VexHotkeys.BugNetKey.JustPressed)
            {
                if (player.itemAnimation == 0 && !quickUsing)
                {
                    for (int i = 0; i < player.inventory.Length; i++)
                    {
                        Item item = player.inventory[i];

                        if (item.stack > 0 && item.Name.Contains("Bug Net"))
                        {
                            player.selectedItem = i;
                            player.controlUseItem = true;
                            player.ItemCheck(Main.myPlayer);
                            break;
                        }
                    }
                }
            }

            // Read off today's quest fish
            if (VexHotkeys.QuestFishKey.JustPressed)
            {
                if(Main.anglerQuestFinished)
                {
                    Main.NewText("You have finished today's quest.");
                }
                else try
                {
                    Item _item = new Item();
                    _item.SetDefaults(Main.anglerQuestItemNetIDs[Main.anglerQuest]);

                    // Do some string magic to find the fish of the day, and where it's caught
                    string message = Lang.AnglerQuestChat(false);

                    int index_split = message.IndexOf("\n\n");

                    string message_1 = message.Substring(0, index_split);
                    string message_2 = message.Substring(index_split + 4).TrimEnd(new char[] { '.', ')' });

                    Main.NewText("\"" + message_1 + "\"", Color.LightGray);
                    Main.NewText("");
                    
                    Main.NewText("Today's quest fish is " + _item.Name + ".");
                    Main.NewText("This fish is c" + message_2 + ".");
                }

                // When you catch an exception instead if a fish
                catch
                {
                    Main.NewText("Error! Today's quest fish is " + Main.anglerQuest + ", but we had a hard time loading the name.");
                    Main.NewText("Talk to the angler for more information!");
                }
            }

            // Quick use tome of improved sight or tome of true sight
            if (VexHotkeys.TomeKey.JustPressed)
            {
                if (player.itemAnimation == 0 && !quickUsing)
                {
                    for (int i = 0; i < player.inventory.Length; i++)
                    {
                        Item item = player.inventory[i];

                        if (item.stack > 0 && (item.Name == "Tome of Improved Sight" || item.Name == "Tome of True Sight") )
                        {
                            QuickUseItem(item, i);
                            break;
                        }
                    }
                }
            }


            // Check if the altUseHotkey was just released this frame
            if (altUseHotkey != null && altUseHotkey.JustReleased)
            {
                // Reset alt-use information
                altUseHeldDown = false;
                revertToHotbar = true;
                altUseHotkey = null;
            }

            // Check for quick-use hotkeys if applicable
            if(player.itemAnimation == 0 && !quickUsing)
            {
                ModHotKey[] quickUses = new ModHotKey[] { VexHotkeys.QuickUseKey1, VexHotkeys.QuickUseKey2, VexHotkeys.QuickUseKey3, VexHotkeys.QuickUseKey4, VexHotkeys.QuickUseKey5, VexHotkeys.QuickUseKey6, VexHotkeys.QuickUseKey7, VexHotkeys.QuickUseKey8, VexHotkeys.QuickUseKey9, VexHotkeys.QuickUseKey10, VexHotkeys.QuickUseKey11, VexHotkeys.QuickUseKey12, VexHotkeys.QuickUseKey13, VexHotkeys.QuickUseKey14, VexHotkeys.QuickUseKey15, VexHotkeys.QuickUseKey16, VexHotkeys.QuickUseKey17, VexHotkeys.QuickUseKey18, VexHotkeys.QuickUseKey19 };
                for (int i = 0; i < 19; i++)
                {
                    // If the key was just pressed, it's go-time
                    if (quickUses[i].JustPressed)
                    {
                        // If the key was right-clicked, we need to check for validity
                        if(quickUses[i].GetAssignedKeys().Contains("Mouse2"))
                        {
                            // The item won't be used if the player can't right click without being interrupted
                            // The item also won't be used if the player is holding up
                            if (PlayerInput.Triggers.Current.Up || !canUseAltItemWithoutBeingInterrupted())
                            {
                                continue;
                            }
                        }

                        // Remember the used item if the item is in the hotbar
                        if (player.selectedItem < 10)
                        {
                            altUseIndex = player.selectedItem;
                        }

                        // Remember which key is being held
                        altUseHotkey = quickUses[i];

                        // Remember that we're alt-using an item
                        altUseHeldDown = true;

                        // Remember which item is being used
                        player.selectedItem = i;
                        
                        Item item = player.inventory[player.selectedItem];

                        // If the item is channeled, we have to force mouse-left input
                        if (item.channel)
                        {
                            player.channel = true;
                            player.controlUseItem = true;
                            PlayerInput.Triggers.JustPressed.MouseLeft = true;
                            player.ItemCheck(Main.myPlayer);
                            player.itemTime = 2;
                            player.itemAnimation = 2;
                        }
                        else
                        {
                            player.controlUseItem = true;
                            player.ItemCheck(Main.myPlayer);
                        }
                        
                        // Only check for one-quick per frame
                        break;
                    }
                }
            }

            base.ProcessTriggers(triggersSet);
        }

        // Returns true if there is nothing that can be right-clicked under the mouse's cursor
        // Returns false otherwise
        //
        // Known bug - if you interact with certain items, such as doors, using the smart-cursor,
        //             this function will return true, even though it should return false.
        private bool canUseAltItemWithoutBeingInterrupted()
        {
            // Inventory
            if (Main.HoverItem.netID != 0)
            {
                return false;
            }

            // NPC
            if(Main.HoveringOverAnNPC)
            {
                return false;
            }
            
            // Buff cancel
            try
            {
                // Buff is under cursor - return false
                if (Main.buffString.Length > 0)
                {
                    return false;
                }
            }

            // Null exception for some reason - continue, as there wouldn't be a buff under the cursor
            catch
            {
            }

            // Tile (and piggy bank projectile)
            if (player.noThrow == 2)
            {
                // Tile can be interacted with - see if it's close enough
                int radius_x = player.lastTileRangeX - 1;
                int radius_y = player.lastTileRangeY - 1;

                Vector2 mousePosition = Main.MouseWorld;

                int mouseX = (int)(mousePosition.X / 16f);
                int mouseY = (int)(mousePosition.Y / 16f);

                int player_x = (int)player.Center.X / 16;
                int player_y = (int)player.Center.Y / 16;


                // Mouse is to left of player
                if (mouseX < player_x)
                {
                    player_x = (int)(player.Left.X / 16);
                }

                // Mouse is to right of player
                else
                {
                    player_x = (int)(player.Right.X / 16);

                }

                // Mouse is above player
                if (mouseY < player_y)
                {
                    player_y = (int)(player.Top.Y / 16);
                }

                // Mouse is below player
                else
                {
                    player_y = (int)(player.Bottom.Y / 16);
                }
                
                // Rectangle representing invalid hitbox
                Rectangle rect = new Rectangle((player_x - radius_x), (player_y - radius_y), (radius_x * 2) + 1, (radius_y * 2));

                // Invalid hitbox contains the mouse position, return false
                if (rect.Contains(mouseX, mouseY))
                {
                    return false;
                }
            }

            return true;
        }


        public override void PreUpdate()
        {
            // If we're quick-using, check for quick-use time to be up
            if (quickUsing)
            {
                // Done quick-using the item - revert to last item
                if (quickUseTime == 0)
                {
                    quickUsing = false;
                    player.selectedItem = lastUseIndex;
                }

                // Not done quick-using - decrement timer
                else
                {
                    quickUseTime--;
                }
            }

            // If we need to revert to the last item used, and we're able to do it, do it.
            if (revertToHotbar && player.itemAnimation <= 1)
            {
                revertToHotbar = false;
                player.selectedItem = altUseIndex;
            }

            // If alt-use is held down, don't check the rest
            if (altUseHeldDown == false) { base.PreUpdate(); return; }

            // Alt use is held down - see if it's still held down this frame
            altUseHeldDown = altUseHotkey.Current;
            
            // If alt-use is still held down, continue alt-using item
            if (altUseHeldDown)
            {
                player.controlUseItem = true;
                Item item = player.inventory[player.selectedItem];

                // If alt-use item is channeled, force mouse-left input
                if (item.channel)
                {
                    player.channel = true;
                    player.controlUseItem = true;
                    PlayerInput.Triggers.Current.MouseLeft = true;
                    forceMouseLeft = true;
                }

                // If the item is done being used, reuse it if possible
                else if (player.itemAnimation <= 1)
                {
                    if (item.autoReuse)
                    {
                        PlayerInput.Triggers.Current.MouseLeft = true;
                        //player.ItemCheck(Main.myPlayer);
                    }
                }
            }

            base.PreUpdate();
        }
    }
}
